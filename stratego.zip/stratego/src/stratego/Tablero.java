
package stratego;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.*;
import java.io.*;


public class Tablero {
    
    static Ficha[][] arregloFichas = new Ficha[10][10];
    static Ficha[] fichasHeroe = new Ficha[35];
    static Ficha[] fichasVillano = new Ficha[35];
    static JPanel panelTablero;
    static Ficha fichaSELECT;
    static int fichaSELECTx, fichaSELECTy;

    public static void main(String[] args) {
       stratego();
    }
    
    public static void stratego() {
        JFrame frame = new JFrame("Tablero");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        BufferedImage image = null;
        try {
            image = ImageIO.read(Tablero.class.getResource("/images/tablero.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(640, 640));

        
        ImageIcon imageIcon = new ImageIcon(image);
        JLabel label = new JLabel(imageIcon);
        label.setBounds(0, 0, 640, 640);

        
        panelTablero = new JPanel(new GridLayout(10, 10));
        panelTablero.setOpaque(false);
        panelTablero.setLayout( new GridLayout(10, 10) );


        int buttonSize = Math.min(image.getWidth() / 10, image.getHeight() / 10);
        
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton(" ");
            button.setOpaque(false);
            button.setContentAreaFilled(false);
            button.setBorder(BorderFactory.createLineBorder(Color.BLUE));
            button.setPreferredSize(new Dimension(buttonSize, buttonSize));
            
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JButton clickedButton = (JButton)e.getSource();
                    int x = clickedButton.getX() / 64; // dividir por el tamano (64) para saber el indice
                    int y = clickedButton.getY() / 64;
                    
                    Ficha ficha = arregloFichas[x][y];
                    if (ficha != null && fichaSELECT==null) { //pick
                        JOptionPane.showMessageDialog(null, "Seleccionaste: " + ficha.getNombre());
                        fichaSELECT=ficha;
                        fichaSELECTx=x;
                        fichaSELECTy=y;
                        
                    }else if(fichaSELECT!=null){//set
                        //x,y are current. fichaSELCETx y fichaSELECTy are old
                        //if()
                        
                        if(ficha==null){//mover a casilla vacilla
                            int[]coordenadasOLD=new int[2];
                            coordenadasOLD[0]=fichaSELECTx;
                            coordenadasOLD[1]=fichaSELECTy;
                            
                            int[] coordenadas=new int[2];
                            coordenadas[0]=x;
                            coordenadas[1]=y;
                            
                            quitarFicha(coordenadasOLD);
                            ponerFicha(fichaSELECT,coordenadas);
                            fichaSELECT=null;
                        }else{
                            //attack/comer ficha
                            
                        }
                        
                    }
                }//action boton
            });

            panelTablero.add(button);
        }
        
        
        Dimension overlaySize = new Dimension(buttonSize * 10, buttonSize * 10);
        int x = (640 - overlaySize.width) / 2;
        int y = (640 - overlaySize.height) / 2;
        panelTablero.setBounds(x, y, overlaySize.width, overlaySize.height);

        
        layeredPane.add(label, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(panelTablero, JLayeredPane.PALETTE_LAYER);

        
        frame.getContentPane().add(layeredPane);

        
        frame.setSize(640, 680);
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
        
        llenarTablero();
    }
    
    public static void llenarTablero() {
        generarHeroes();
        generarVillanos();
        
//        TIERRAS
        int[] coordenadasTierraHeroes = obtenerCasillaTierra(true);
        int[] coordenadasTierraVillanos = obtenerCasillaTierra(false);
        
        Ficha fichaTierraHeroes = fichasHeroe[34];
        Ficha fichaTierraVillanos = fichasVillano[34];

        int indicePanelTierraHeroes = combertirCoordenada(coordenadasTierraHeroes[0], coordenadasTierraHeroes[1]);
        int indicePanelTierraVillanos = combertirCoordenada(coordenadasTierraVillanos[0], coordenadasTierraVillanos[1]);
        
        Image imgTierraHeroes;
        Image imgTierraVillanos;
        try {
            imgTierraHeroes = ImageIO.read(Tablero.class.getResource(fichaTierraHeroes.getImagen()));
            imgTierraVillanos = ImageIO.read(Tablero.class.getResource(fichaTierraVillanos.getImagen()));
        } catch (IOException e) {
            e.printStackTrace();
            imgTierraHeroes = null;
            imgTierraVillanos = null;
        }
        
        JButton casillaTierra = (JButton)panelTablero.getComponent(indicePanelTierraHeroes);
        casillaTierra.setIcon(new ImageIcon(imgTierraHeroes));
        
        JButton casillaVillanos = (JButton)panelTablero.getComponent(indicePanelTierraVillanos);
        casillaVillanos.setIcon(new ImageIcon(imgTierraVillanos));
        
        arregloFichas[coordenadasTierraHeroes[0]][coordenadasTierraHeroes[1]] = fichaTierraHeroes;
        arregloFichas[coordenadasTierraVillanos[0]][coordenadasTierraVillanos[1]] = fichaTierraVillanos;

        //BOMBAS
        ponerBombas(coordenadasTierraHeroes, true);
        ponerBombas(coordenadasTierraVillanos, false);
        
        // Bombas restantes
        int[] casillaBomba1 = obtenerCasillaLibre(0,1);
        ponerFicha(new Ficha("Nova Blast", 0, true, false, true, "Nova Blast"), casillaBomba1);
        int[] casillaBomba2 = obtenerCasillaLibre(0,1);
        ponerFicha(new Ficha("Nova Blast", 0, true, false, true, "Nova Blast"), casillaBomba2);
        int[] casillaBomba3 = obtenerCasillaLibre(0,1);
        ponerFicha(new Ficha("Nova Blast", 0, true, false, true, "Nova Blast"), casillaBomba3);
        
        int[] casillaBombaVillanos1 = obtenerCasillaLibre(8,9);
        ponerFicha(new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb"), casillaBombaVillanos1);
        int[] casillaBombaVillanos2 = obtenerCasillaLibre(8,9);
        ponerFicha(new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb"), casillaBombaVillanos2);
        int[] casillaBombaVillanos3 = obtenerCasillaLibre(8,9);
        ponerFicha(new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb"), casillaBombaVillanos3);
        
        
//        RANGO 2
        ponerFichasPorRango(true, 2, 9, 2, 3);
        ponerFichasPorRango(false, 2, 9, 6, 7);
        
//        RANGO 3
        ponerFichasPorRango(true, 10, 33, 0, 3);
        ponerFichasPorRango(false, 10, 33, 6, 9);
        
    }
    
    public static void ponerFichasPorRango(boolean heroes, int indiceRango1, int indiceRango2, int filaInicio, int filaFinal) {
        Ficha[] fichas = new Ficha[35];
        if (heroes) {
            fichas = fichasHeroe;
        } else {
            fichas = fichasVillano;
        }
        
        while(indiceRango1 <= indiceRango2) {
            int[] casillaLibre = obtenerCasillaLibre(filaInicio,filaFinal);
            Ficha ficha = fichas[indiceRango1];
            ponerFicha(ficha, casillaLibre);
            indiceRango1++;
        }
    }
    
    public static void ponerBombas(int[] coordenadasTierra, boolean heroe) {
        
        int[] coordenadasBomba1 = {coordenadasTierra[0]+1, coordenadasTierra[1]};
        int[] coordenadasBomba2 = {coordenadasTierra[0]-1, coordenadasTierra[1]};
        int[] coordenadasBomba3 = new int[2];
        if (heroe) {
            coordenadasBomba3[0] = coordenadasTierra[0];
            coordenadasBomba3[1] = coordenadasTierra[1]+1;
        } else {
            coordenadasBomba3[0] = coordenadasTierra[0];
            coordenadasBomba3[1] = coordenadasTierra[1]-1;
        }
        
        Ficha bomba1;
        Ficha bomba2;
        Ficha bomba3;
        if (heroe) {
            bomba1 = new Ficha("Nova Blast", 0, true, false, true, "Nova Blast");
            bomba2 = new Ficha("Nova Blast", 0, true, false, true, "Nova Blast");
            bomba3 = new Ficha("Nova Blast", 0, true, false, true, "Nova Blast");
        } else {
            bomba1 = new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb");
            bomba2 = new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb");
            bomba3 = new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb");   
        }
    
        ponerFicha(bomba1, coordenadasBomba1);
        ponerFicha(bomba2, coordenadasBomba2);
        ponerFicha(bomba3, coordenadasBomba3);
    }
    
    public static void ponerFicha(Ficha ficha, int[] coordenadas) {
        int indiceBoton = combertirCoordenada(coordenadas[0], coordenadas[1]);
        arregloFichas[coordenadas[0]][coordenadas[1]] = ficha;
        JButton casilla = (JButton)panelTablero.getComponent(indiceBoton);
        Image img;
        try {
            img = ImageIO.read(Tablero.class.getResource(ficha.getImagen()));
        } catch (IOException e) {
            e.printStackTrace();
            img = null;
        }
        casilla.setIcon(new ImageIcon(img));
    }
    
    public static Ficha quitarFicha(int[] coordenadas){
        int indiceBoton = combertirCoordenada(coordenadas[0], coordenadas[1]);
        Ficha removedFicha=arregloFichas[coordenadas[0]][coordenadas[1]];
        arregloFichas[coordenadas[0]][coordenadas[1]]=null;
        JButton casilla = (JButton)panelTablero.getComponent(indiceBoton);
        casilla.setIcon(null);
        
        return removedFicha;
    }
    
    public static int[] obtenerCasillaTierra(Boolean heroes) {
        int min = 1;
        int max = 8;
        int x = (int)Math.floor(Math.random() * (max - min + 1) + min);
        int y;
        if (heroes) {
            y = 0;
        } else {
            y = 9;
        }
        int[] arr = {x,y};
        return arr;
    }
    
    public static int[] obtenerCasillaLibre(int yInicial, int yFinal) {
        int y = (int)Math.floor(Math.random() * (yFinal - yInicial + 1) + yInicial);
        int min = 0;
        int max = 9;
        int x = (int)Math.floor(Math.random() * (max - min + 1) + min);
        
        Ficha ficha = arregloFichas[x][y];
        if (ficha != null) {
            return obtenerCasillaLibre(yInicial, yFinal);
        } else {
            int[] arr = {x, y};
            return arr;
        }
    }
    
    public static int combertirCoordenada(int x, int y){
        return (y * 10) + x;
    }
    
    public static void generarVillanos() {
        fichasVillano[0] = new Ficha("Pumpkin Bomb", 0, true, false, false, "Pumpkin Bomb");
        fichasVillano[1] = new Ficha("Black Widow (V)", 1, false, false, false, "Rango 1");
        fichasVillano[2] = new Ficha("Sentinel 1", 2, false, false, false, "Rango 2.1");
        fichasVillano[3] = new Ficha("Sentinel 2", 2, false, false, false, "Rango 2.2");
        fichasVillano[4] = new Ficha("Ultron", 2, false, false, false, "Rango 2.3");
        fichasVillano[5] = new Ficha("Mr. Sinister", 2, false, false, false, "Rango 2.4");
        fichasVillano[6] = new Ficha("Sandman", 2, false, false, false, "Rango 2.5");
        fichasVillano[7] = new Ficha("Leader", 2, false, false, false, "Rango 2.6");
        fichasVillano[8] = new Ficha("Viper", 2, false, false, false, "Rango 2.7");
        fichasVillano[9] = new Ficha("Electro", 2, false, false, false, "Rango 2.8");
        fichasVillano[10] = new Ficha("Rhino", 3, false, false, false, "Rango 3.1");
        fichasVillano[11] = new Ficha("Lizard", 3, false, false, false, "Rango 3.2");
        fichasVillano[12] = new Ficha("Mole Man", 3, false, false, false, "Rango 3.3");
        fichasVillano[13] = new Ficha("Juggernaut", 3, false, false, false, "Rango 3.4");
        fichasVillano[14] = new Ficha("Carnage", 3, false, false, false, "Rango 3.5");
        fichasVillano[15] = new Ficha("Black Cat", 4, false, false, false, "Rango 4.1");
        fichasVillano[16] = new Ficha("Thanos", 4, false, false, false, "Rango 4.2");
        fichasVillano[17] = new Ficha("Abomination", 4, false, false, false, "Rango 4.3");
        fichasVillano[18] = new Ficha("Sabretooth", 4, false, false, false, "Rango 4.4");
        fichasVillano[19] = new Ficha("Mystique", 5, false, false, false, "Rango 5.1");
        fichasVillano[20] = new Ficha("Dr. Octopus", 5, false, false, false, "Rango 5.2");
        fichasVillano[21] = new Ficha("Mysterio", 5, false, false, false, "Rango 5.3");
        fichasVillano[22] = new Ficha("Deadpool", 5, false, false, false, "Rango 5.4");
        fichasVillano[23] = new Ficha("Omega Red", 6, false, false, false, "Rango 6.1");
        fichasVillano[24] = new Ficha("Red Skull", 6, false, false, false, "Rango 6.2");
        fichasVillano[25] = new Ficha("Onslaught", 6, false, false, false, "Rango 6.3");
        fichasVillano[26] = new Ficha("Bullseye", 6, false, false, false, "Rango 6.4");
        fichasVillano[27] = new Ficha("Apocalypse", 7, false, false, false, "Rango 7.1");
        fichasVillano[28] = new Ficha("Green Goblin", 7, false, false, false, "Rango 7.2");
        fichasVillano[29] = new Ficha("Venom", 7, false, false, false, "Rango 7.3");
        fichasVillano[30] = new Ficha("Kingpin", 8, false, false, false, "Rango 8.1");
        fichasVillano[31] = new Ficha("Magneto", 8, false, false, false, "Rango 8.2");
        fichasVillano[32] = new Ficha("Galactus", 9, false, false, false, "Rango 9");
        fichasVillano[33] = new Ficha("Dr. Doom", 10, false, false, false, "Rango 10");
        fichasVillano[34] = new Ficha("Tierra Villanos", 100, false, false, false, "Tierra-Villanos");
    }
    
    public static void generarHeroes() {
        fichasHeroe[0] = new Ficha("Nova Blast", 0, true, false, true, "Nova Blast");
        fichasHeroe[1] = new Ficha("Black Widow", 1, false, false, true, "Rango 1");
        fichasHeroe[2] = new Ficha("Nightcrawler", 2, false, false, true, "Rango 2.1");
        fichasHeroe[3] = new Ficha("Storm", 2, false, false, true, "Rango 2.2");
        fichasHeroe[4] = new Ficha("Dr. Strange", 2, false, false, true, "Rango 2.3");
        fichasHeroe[5] = new Ficha("Phoenix", 2, false, false, true, "Rango 2.4");
        fichasHeroe[6] = new Ficha("Gambit", 2, false, false, true, "Rango 2.5");
        fichasHeroe[7] = new Ficha("Spider-Girl", 2, false, false, true, "Rango 2.6");
        fichasHeroe[8] = new Ficha("Ice Man", 2, false, false, true, "Rango 2.7");
        fichasHeroe[9] = new Ficha("Elektra", 2, false, false, true, "Rango 2.8");
        fichasHeroe[10] = new Ficha("Emma Frost", 3, false, false, true, "Rango 3.1");
        fichasHeroe[11] = new Ficha("She-Hulk", 3, false, false, true, "Rango 3.2");
        fichasHeroe[12] = new Ficha("Colossus", 3, false, false, true, "Rango 3.3");
        fichasHeroe[13] = new Ficha("Ant Man", 3, false, false, true, "Rango 3.4");
        fichasHeroe[14] = new Ficha("Beast", 3, false, false, true, "Rango 3.5");
        fichasHeroe[15] = new Ficha("Thing", 4, false, false, true, "Rango 4.1");
        fichasHeroe[16] = new Ficha("Punisher", 4, false, false, true, "Rango 4.2");
        fichasHeroe[17] = new Ficha("Blade", 4, false, false, true, "Rango 4.3");
        fichasHeroe[18] = new Ficha("Ghost Rider", 4, false, false, true, "Rango 4.4");
        fichasHeroe[19] = new Ficha("Human Torch", 5, false, false, true, "Rango 5.1");
        fichasHeroe[20] = new Ficha("Invisible Woman", 5, false, false, true, "Rango 5.2");
        fichasHeroe[21] = new Ficha("Cyclops", 5, false, false, true, "Rango 5.3");
        fichasHeroe[22] = new Ficha("Thor", 5, false, false, true, "Rango 5.4");
        fichasHeroe[23] = new Ficha("Iron Man", 6, false, false, true, "Rango 6.1");
        fichasHeroe[24] = new Ficha("Hulk", 6, false, false, true, "Rango 6.2");
        fichasHeroe[25] = new Ficha("Silver Surfer", 6, false, false, true, "Rango 6.3");
        fichasHeroe[26] = new Ficha("Daredevil", 6, false, false, true, "Rango 6.4");
        fichasHeroe[27] = new Ficha("Namor", 7, false, false, true, "Rango 7.1");
        fichasHeroe[28] = new Ficha("Wolverine", 7, false, false, true, "Rango 7.2");
        fichasHeroe[29] = new Ficha("Spiderman", 7, false, false, true, "Rango 7.3");
        fichasHeroe[30] = new Ficha("Nick Fury", 8, false, false, true, "Rango 8.1");
        fichasHeroe[31] = new Ficha("Professor X", 8, false, false, true, "Rango 8.2");
        fichasHeroe[32] = new Ficha("Captain America", 9, false, false, true, "Rango 9");
        fichasHeroe[33] = new Ficha("Mr. Fantastic", 10, false, false, true, "Rango 10");
        fichasHeroe[34] = new Ficha("Tierra Heroes", 100, false, true, true, "Tierra-Heroes");
    }
    
}
